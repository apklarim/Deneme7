package com.apklarim.iptvstarter.parser

data class IptvChannel(
    val name: String,
    val logo: String?,
    val group: String?,
    val streamUrl: String,
    val mediaType: String = "LIVE"
)
