package com.apklarim.iptvstarter.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ChannelDao {
    @Query("SELECT * FROM channels WHERE (:sourceId IS NULL OR sourceId = :sourceId) ORDER BY groupName, name LIMIT :limit")
    suspend fun getChannels(sourceId: Long?, limit: Int = 100000): List<ChannelEntity>

    @Query("""
        SELECT * FROM channels
        WHERE (:sourceId IS NULL OR sourceId = :sourceId)
        AND mediaType = :mediaType
        ORDER BY groupName, name
        LIMIT :limit
    """)
    suspend fun getChannelsByType(sourceId: Long?, mediaType: String, limit: Int = 100000): List<ChannelEntity>

    @Query("""
        SELECT * FROM channels
        WHERE (:sourceId IS NULL OR sourceId = :sourceId)
        AND (name LIKE '%' || :query || '%' OR groupName LIKE '%' || :query || '%')
        ORDER BY groupName, name
        LIMIT :limit
    """)
    suspend fun search(sourceId: Long?, query: String, limit: Int = 5000): List<ChannelEntity>

    @Query("SELECT COUNT(*) FROM channels WHERE (:sourceId IS NULL OR sourceId = :sourceId)")
    suspend fun count(sourceId: Long?): Int

    @Query("DELETE FROM channels WHERE sourceId = :sourceId")
    suspend fun clearForSource(sourceId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(channels: List<ChannelEntity>)

    @Query("UPDATE channels SET lastPlayedAt = :timestamp WHERE id = :id")
    suspend fun markPlayed(id: Long, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE channels SET isFavorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: Long, favorite: Boolean)
}
