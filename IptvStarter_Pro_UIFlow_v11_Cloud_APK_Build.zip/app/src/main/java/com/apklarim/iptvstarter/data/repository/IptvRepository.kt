package com.apklarim.iptvstarter.data.repository

import com.apklarim.iptvstarter.data.local.ChannelDao
import com.apklarim.iptvstarter.data.local.ChannelEntity
import com.apklarim.iptvstarter.data.local.SourceDao
import com.apklarim.iptvstarter.data.local.SourceEntity
import com.apklarim.iptvstarter.data.remote.PlaylistDownloader
import com.apklarim.iptvstarter.parser.M3uParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URLEncoder

class IptvRepository(
    private val channelDao: ChannelDao,
    private val sourceDao: SourceDao,
    private val downloader: PlaylistDownloader = PlaylistDownloader(),
    private val parser: M3uParser = M3uParser()
) {
    suspend fun sources(): List<SourceEntity> = sourceDao.getAll()

    suspend fun sourcesByType(type: String): List<SourceEntity> = sourceDao.getAll().filter { it.type == type }

    suspend fun channels(sourceId: Long?, query: String? = null): Pair<List<ChannelEntity>, Int> {
        val q = query.orEmpty().trim()
        val list = if (q.isBlank()) channelDao.getChannels(sourceId) else channelDao.search(sourceId, q)
        val total = channelDao.count(sourceId)
        return list to total
    }

    suspend fun deleteSource(source: SourceEntity) {
        channelDao.clearForSource(source.id)
        sourceDao.delete(source)
    }

    suspend fun saveMag(name: String, portalUrl: String, mac: String?): Long {
        return sourceDao.insert(
            SourceEntity(
                name = name.ifBlank { "MAG Portal" },
                type = SourceEntity.TYPE_MAG,
                url = portalUrl,
                magMac = mac?.ifBlank { null },
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun importM3uUrl(name: String, url: String, existingId: Long? = null): Int {
        val cleanUrl = url.trim()
        // Önemli: Önce indirip parse ediyoruz. Bağlantı yanlışsa eski kayıt/link silinmez veya bozulmaz.
        val content = downloader.download(cleanUrl)
        val parsedCount = parser.parse(content).size
        if (parsedCount == 0) error("M3U içinde kanal bulunamadı")
        val sourceId = upsertSource(
            existingId,
            SourceEntity(
                id = existingId ?: 0,
                name = name.ifBlank { "M3U Liste" },
                type = SourceEntity.TYPE_M3U_URL,
                url = cleanUrl,
                updatedAt = System.currentTimeMillis()
            )
        )
        return replaceChannels(sourceId, content)
    }

    suspend fun importM3uFile(name: String, displayPath: String, content: String, existingId: Long? = null): Int {
        val parsedCount = parser.parse(content).size
        if (parsedCount == 0) error("Dosya içinde kanal bulunamadı")
        val sourceId = upsertSource(
            existingId,
            SourceEntity(
                id = existingId ?: 0,
                name = name.ifBlank { "M3U Dosyası" },
                type = SourceEntity.TYPE_M3U_FILE,
                url = displayPath,
                updatedAt = System.currentTimeMillis()
            )
        )
        return replaceChannels(sourceId, content)
    }

    suspend fun importXtream(name: String, serverUrl: String, username: String, password: String, existingId: Long? = null): Int {
        val normalizedServer = serverUrl.trim().trimEnd('/')
        val u = URLEncoder.encode(username.trim(), "UTF-8")
        val p = URLEncoder.encode(password.trim(), "UTF-8")
        val m3uUrl = "$normalizedServer/get.php?username=$u&password=$p&type=m3u_plus&output=ts"
        // Önemli: Önce bağlantıyı test ediyoruz. Hata olursa eski Xtream kaydı korunur.
        val content = downloader.download(m3uUrl)
        val parsedCount = parser.parse(content).size
        if (parsedCount == 0) error("Xtream bağlantısından kanal alınamadı")
        val sourceId = upsertSource(
            existingId,
            SourceEntity(
                id = existingId ?: 0,
                name = name.ifBlank { "Xtream Liste" },
                type = SourceEntity.TYPE_XTREAM,
                url = normalizedServer,
                username = username.trim(),
                password = password.trim(),
                updatedAt = System.currentTimeMillis()
            )
        )
        return replaceChannels(sourceId, content)
    }

    suspend fun updateSourceOnly(source: SourceEntity) = sourceDao.update(source.copy(updatedAt = System.currentTimeMillis()))

    suspend fun markPlayed(id: Long) = channelDao.markPlayed(id)

    private suspend fun upsertSource(existingId: Long?, source: SourceEntity): Long {
        return if (existingId != null && existingId > 0) {
            sourceDao.update(source.copy(id = existingId, updatedAt = System.currentTimeMillis()))
            existingId
        } else {
            sourceDao.insert(source)
        }
    }

    private suspend fun replaceChannels(sourceId: Long, content: String): Int = withContext(Dispatchers.Default) {
        val parsed = parser.parse(content)
        val entities = parsed.map {
            ChannelEntity(
                sourceId = sourceId,
                name = it.name,
                logo = it.logo,
                groupName = it.group,
                streamUrl = it.streamUrl,
                mediaType = it.mediaType
            )
        }
        withContext(Dispatchers.IO) {
            channelDao.clearForSource(sourceId)
            entities.chunked(500).forEach { chunk -> channelDao.insertAll(chunk) }
        }
        entities.size
    }
}
