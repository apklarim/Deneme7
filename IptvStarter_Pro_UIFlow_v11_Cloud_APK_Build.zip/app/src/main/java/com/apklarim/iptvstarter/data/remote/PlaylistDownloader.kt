package com.apklarim.iptvstarter.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class PlaylistDownloader {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun download(url: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "IPTV-Starter/0.1")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                error("Playlist indirilemedi: HTTP ${response.code}")
            }
            response.body?.string() ?: error("Boş playlist yanıtı")
        }
    }
}
