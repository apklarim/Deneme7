package com.apklarim.iptvstarter.player

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.apklarim.iptvstarter.data.local.AppDatabase
import com.apklarim.iptvstarter.data.local.ChannelEntity
import com.apklarim.iptvstarter.ui.dp
import com.apklarim.iptvstarter.ui.enableImmersiveFullscreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MultiPlayerActivity : ComponentActivity() {
    private data class CellState(val root: FrameLayout, val playerView: PlayerView, val label: TextView)
    private val players = mutableListOf<ExoPlayer>()
    private val cells = mutableListOf<CellState>()
    private val currentChannels = mutableMapOf<Int, ChannelEntity>()
    private lateinit var overlay: FrameLayout
    private var channels: List<ChannelEntity> = emptyList()
    private var currentSourceId: Long? = null
    private var mediaType: String = ChannelEntity.MEDIA_LIVE
    private var count = 2
    private var activeCellIndex = 0
    private var lastTapAt = 0L
    private var showingChannels = false
    private var lastGroupName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { enableImmersiveFullscreen() }
        count = intent.getIntExtra(EXTRA_COUNT, 2).coerceIn(2, 4)
        currentSourceId = intent.getLongExtra(EXTRA_SOURCE_ID, -1L).takeIf { it > 0 }
        mediaType = intent.getStringExtra(EXTRA_MEDIA_TYPE) ?: ChannelEntity.MEDIA_LIVE
        lastGroupName = prefs().getString(lastGroupKey(), null)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); fitsSystemWindows = false; isFocusable = true; isFocusableInTouchMode = true }
        val grid = GridLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            columnCount = 2
            rowCount = if (count == 2) 1 else 2
            fitsSystemWindows = false
        }
        root.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        overlay = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(Color.argb(150, 0, 0, 0)); isClickable = true; setOnClickListener { hideOverlay() } }
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        root.requestFocus()

        lifecycleScope.launch {
            channels = runCatching {
                withContext(Dispatchers.IO) { AppDatabase.get(this@MultiPlayerActivity).channelDao().getChannels(currentSourceId, 30000) }
                    .filter { it.mediaType == mediaType }
                    .sortedWith(compareBy<ChannelEntity> { it.groupName ?: "Genel" }.thenBy { it.name })
            }.getOrElse { emptyList() }

            if (channels.isEmpty()) {
                Toast.makeText(this@MultiPlayerActivity, "Çoklu ekran için önce kanal listesi yükleyin", Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            if (lastGroupName.isNullOrBlank()) lastGroupName = groupOf(channels.first())
            channels.take(count).forEachIndexed { index, channel -> grid.addView(createPlayerCell(channel, index)) }
        }
    }

    private fun createPlayerCell(channel: ChannelEntity, index: Int): View {
        val cell = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isFocusable = true
            isClickable = true
            setPadding(dp(1), dp(1), dp(1), dp(1))
            layoutParams = GridLayout.LayoutParams().apply {
                width = 0; height = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(0, 0, 0, 0)
            }
        }
        val playerView = PlayerView(this).apply {
            useController = false
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        cell.addView(playerView)
        val label = TextView(this).apply { setTextColor(Color.WHITE); textSize = if (count == 2) 15f else 12f; setBackgroundColor(Color.argb(155, 0, 0, 0)); setPadding(dp(8), dp(5), dp(8), dp(5)); maxLines = 1 }
        cell.addView(label, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        val state = CellState(cell, playerView, label)
        cells.add(state)
        val player = ExoPlayer.Builder(this).build()
        players.add(player)
        playerView.player = player
        playInCell(index, channel)

        cell.setOnClickListener {
            val now = System.currentTimeMillis()
            activeCellIndex = index
            if (now - lastTapAt < 420) showLastGroupOrGroupsForCell(index) else selectAudio(index)
            lastTapAt = now
        }
        cell.setOnFocusChangeListener { _, hasFocus -> if (hasFocus) activeCellIndex = index }
        return cell
    }

    private fun playInCell(index: Int, channel: ChannelEntity) {
        val state = cells.getOrNull(index) ?: return
        val player = players.getOrNull(index) ?: return
        currentChannels[index] = channel
        lastGroupName = groupOf(channel)
        prefs().edit().putString(lastGroupKey(), lastGroupName).apply()
        state.label.text = "${index + 1}. ${channel.name.ifBlank { "Kanal" }}"
        val url = channel.streamUrl.substringBefore('|').trim()
        if (!isPlayableUrl(url)) { Toast.makeText(this, "Geçersiz link: ${channel.name}", Toast.LENGTH_SHORT).show(); return }
        runCatching {
            player.stop(); player.clearMediaItems(); player.setMediaItem(MediaItem.fromUri(Uri.parse(url))); player.prepare(); player.playWhenReady = true; player.volume = if (index == activeCellIndex) 1f else 0f
        }
        hideOverlay()
    }

    private fun selectAudio(index: Int) {
        activeCellIndex = index
        players.forEachIndexed { i, p -> p.volume = if (i == index) 1f else 0f }
        currentChannels[index]?.let { Toast.makeText(this, "Ses: ${it.name}", Toast.LENGTH_SHORT).show() }
    }

    private fun showLastGroupOrGroupsForCell(index: Int) {
        activeCellIndex = index
        val group = lastGroupName?.takeIf { g -> channels.any { groupOf(it) == g } && !hiddenGroups().contains(g) }
        if (group != null) showChannels(group) else showGroups(false)
    }

    private fun showGroups(includeHidden: Boolean) {
        if (channels.isEmpty()) return
        showingChannels = false
        val hidden = hiddenGroups()
        val groups = channels.map { groupOf(it) }.distinct().sorted().filter { includeHidden || !hidden.contains(it) }
        val title = if (includeHidden) "Gizli Gruplar" else "Gruplar"
        renderGroupOverlay(title, groups, includeHidden)
    }

    private fun showChannels(group: String) {
        if (hiddenGroups().contains(group)) { Toast.makeText(this, "Bu grup gizli", Toast.LENGTH_SHORT).show(); return }
        lastGroupName = group
        prefs().edit().putString(lastGroupKey(), group).apply()
        showingChannels = true
        val items = channels.filter { groupOf(it) == group }
        renderChannelOverlay("$group (${items.size})", items)
    }

    private fun renderGroupOverlay(title: String, groups: List<String>, includeHidden: Boolean) {
        overlay.removeAllViews(); overlay.visibility = View.VISIBLE
        val panel = panelBase()
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(controlButton("←") { hideOverlay() })
        head.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(10),0,dp(8),dp(10)) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        panel.addView(head)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(controlButton("👁 Gizliler") { showGroups(true) })
        panel.addView(actions)
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = true }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        groups.forEach { group ->
            val prefix = when { hiddenGroups().contains(group) -> "🙈 "; adultGroups().contains(group) -> "🔒 "; else -> "" }
            list.addView(menuRow(prefix + group) {
                if (adultGroups().contains(group)) askAdultPin { showChannels(group) } else showChannels(group)
            }.apply { setOnLongClickListener { groupOptions(group, includeHidden); true } })
        }
        panel.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        overlay.addView(panel, FrameLayout.LayoutParams(panelWidth(), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END))
    }

    private fun renderChannelOverlay(title: String, items: List<ChannelEntity>) {
        overlay.removeAllViews(); overlay.visibility = View.VISIBLE
        val panel = panelBase()
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(controlButton("←") { showGroups(false) })
        head.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 21f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(10),0,dp(8),dp(10)) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        panel.addView(head)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(controlButton("← Gruplar") { showGroups(false) })
        actions.addView(controlButton("↩ Kapat") { hideOverlay() })
        panel.addView(actions)
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = true }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        items.forEach { ch ->
            val pos = channels.indexOfFirst { it.id == ch.id }.takeIf { it >= 0 }?.plus(1) ?: 0
            val name = if (pos > 0) "$pos. ${ch.name.ifBlank { "İsimsiz Kanal" }}" else ch.name.ifBlank { "İsimsiz Kanal" }
            list.addView(menuRow(name) { playInCell(activeCellIndex, ch); selectAudio(activeCellIndex) })
        }
        panel.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        overlay.addView(panel, FrameLayout.LayoutParams(panelWidth(), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END))
    }

    private fun groupOptions(group: String, includeHidden: Boolean) {
        val hidden = hiddenGroups().contains(group)
        val adult = adultGroups().contains(group)
        val opts = arrayOf(if (hidden) "Göster" else "Gizle", if (adult) "Adult şifresini kaldır" else "Adult şifresi koy", "İptal")
        AlertDialog.Builder(this).setTitle(group).setItems(opts) { _, which ->
            when (which) {
                0 -> { if (hidden) unhideGroup(group) else hideGroup(group); showGroups(hidden) }
                1 -> { if (adult) removeAdultGroup(group) else setAdultGroupWithPin(group) }
            }
        }.show()
    }

    private fun setAdultGroupWithPin(group: String) {
        val input = EditText(this).apply { hint = "4 haneli şifre"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("Adult şifresi").setView(input).setPositiveButton("Kaydet") { _, _ ->
            val pin = input.text.toString().trim()
            if (pin.length < 4) Toast.makeText(this, "En az 4 haneli şifre girin", Toast.LENGTH_LONG).show()
            else { prefs().edit().putString(adultPinKey(), pin).putStringSet(adultGroupsKey(), adultGroups() + group).apply(); Toast.makeText(this, "Adult şifresi eklendi", Toast.LENGTH_SHORT).show(); showGroups(false) }
        }.setNegativeButton("Vazgeç", null).show()
    }

    private fun askAdultPin(onOk: () -> Unit) {
        val pin = prefs().getString(adultPinKey(), null)
        if (pin.isNullOrBlank()) { onOk(); return }
        val input = EditText(this).apply { hint = "Şifre"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("Adult şifresi").setView(input).setPositiveButton("Aç") { _, _ -> if (input.text.toString() == pin) onOk() else Toast.makeText(this, "Şifre yanlış", Toast.LENGTH_LONG).show() }.setNegativeButton("Vazgeç", null).show()
    }

    private fun hideGroup(group: String) { prefs().edit().putStringSet(hiddenGroupsKey(), hiddenGroups() + group).apply() }
    private fun unhideGroup(group: String) { prefs().edit().putStringSet(hiddenGroupsKey(), hiddenGroups() - group).apply() }
    private fun removeAdultGroup(group: String) { prefs().edit().putStringSet(adultGroupsKey(), adultGroups() - group).apply(); Toast.makeText(this, "Adult koruması kaldırıldı", Toast.LENGTH_SHORT).show(); showGroups(false) }
    private fun hiddenGroups(): Set<String> = prefs().getStringSet(hiddenGroupsKey(), emptySet()) ?: emptySet()
    private fun adultGroups(): Set<String> = prefs().getStringSet(adultGroupsKey(), emptySet()) ?: emptySet()

    private fun panelBase() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = pill(Color.argb(238, 7, 20, 36)); isClickable = true }
    private fun panelWidth(): Int = if (resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) dp(470) else ViewGroup.LayoutParams.MATCH_PARENT
    private fun menuRow(text: String, click: () -> Unit): View = TextView(this).apply {
        this.text = text; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; maxLines = 1; gravity = Gravity.CENTER_VERTICAL
        isFocusable = true; isClickable = true; setPadding(dp(14), dp(12), dp(14), dp(12)); background = selectablePill(Color.rgb(16,31,50), Color.rgb(62,98,142)); setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, dp(4), 0, dp(4)) }
    }
    private fun controlButton(text: String, click: () -> Unit): TextView = TextView(this).apply { this.text = text; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER; isFocusable = true; isClickable = true; setPadding(dp(13), dp(9), dp(13), dp(9)); background = selectablePill(Color.rgb(22,52,72), Color.rgb(62,98,142)); setOnClickListener { click() }; layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(5),0,dp(5),dp(6)) } }
    private fun pill(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.argb(90,255,255,255)) }
    private fun selectablePill(normal: Int, focused: Int) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), GradientDrawable().apply { setColor(Color.rgb(50, 130, 210)); cornerRadius = dp(18).toFloat(); setStroke(dp(2), Color.WHITE) })
        addState(intArrayOf(android.R.attr.state_focused), GradientDrawable().apply { setColor(focused); cornerRadius = dp(18).toFloat(); setStroke(dp(3), Color.rgb(210, 235, 255)) })
        addState(intArrayOf(), GradientDrawable().apply { setColor(normal); cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.argb(120,255,255,255)) })
    }

    private fun hideOverlay() { overlay.visibility = View.GONE; overlay.removeAllViews(); showingChannels = false }
    private fun groupOf(ch: ChannelEntity) = ch.groupName?.ifBlank { "Genel" } ?: "Genel"
    private fun prefs() = getSharedPreferences("player_prefs_v10", MODE_PRIVATE)
    private fun lastGroupKey() = "last_group_${currentSourceId ?: 0}_$mediaType"
    private fun hiddenGroupsKey() = "hidden_groups_${currentSourceId ?: 0}_$mediaType"
    private fun adultGroupsKey() = "adult_groups_${currentSourceId ?: 0}_$mediaType"
    private fun adultPinKey() = "adult_pin_${currentSourceId ?: 0}"
    private fun isPlayableUrl(url: String) = url.startsWith("http://", true) || url.startsWith("https://", true) || url.startsWith("rtmp://", true) || url.startsWith("rtsp://", true)

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) runCatching { enableImmersiveFullscreen() } }
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean { runCatching { enableImmersiveFullscreen() }; return super.dispatchTouchEvent(ev) }
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (overlay.visibility == View.VISIBLE) { if (showingChannels) showGroups(false) else hideOverlay() } else finish()
            return true
        }
        return super.dispatchKeyEvent(event)
    }
    override fun onStop() { super.onStop(); players.forEach { it.release() }; players.clear() }

    companion object {
        const val EXTRA_COUNT = "count"
        const val EXTRA_SOURCE_ID = "source_id"
        const val EXTRA_MEDIA_TYPE = "media_type"
    }
}
